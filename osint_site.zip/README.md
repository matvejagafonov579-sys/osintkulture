# OSINT // Open Source Intelligence

Одностраничный образовательный сайт про OSINT.

## Запуск
Откройте `index.html` в браузере.

## GitHub Pages
Загрузите `index.html` в репозиторий и включите GitHub Pages в Settings → Pages.
